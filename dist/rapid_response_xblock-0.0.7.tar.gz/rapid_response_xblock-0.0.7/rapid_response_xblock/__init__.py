"""rapid_response_xblock Django app"""
__version__ = '0.0.7'
